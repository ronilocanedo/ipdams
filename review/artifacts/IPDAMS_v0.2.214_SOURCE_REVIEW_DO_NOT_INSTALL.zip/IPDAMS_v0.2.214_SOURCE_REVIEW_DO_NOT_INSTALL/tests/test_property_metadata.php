<?php
declare(strict_types=1);
class DomainError extends RuntimeException { public function __construct(string $msg,public int $status=400){parent::__construct($msg);} }
function demand($ok,string $msg,int $status=400):void { if(!$ok)throw new DomainError($msg,$status); }
function mbSafeLen(string $v):int {return strlen($v);}
require dirname(__DIR__).'/candidate/app/PropertyBatchMetadata.php';
$n=0;
function check(bool $pass,string $msg):void {global $n;if(!$pass)throw new RuntimeException('FAIL '.$msg);$n++;}
function rejected(callable $f,string $msg):void {$ok=false;try{$f();}catch(DomainError $e){$ok=true;} check($ok,$msg);}
$x=PropertyBatchMetadata::shared(['brand'=>'Epson','model'=>'L5590','historical_po'=>'PO-2019-11','historical_iar'=>'IAR-25','historical_dv'=>'DV 1','acquisition_type'=>'PURCHASE'],'HISTORICAL_OPENING');
check($x['brand']==='Epson' && $x['historical_dv']==='DV 1','historical evidence retained');
check($x['origin']==='HISTORICAL_OPENING','origin');
rejected(fn()=>PropertyBatchMetadata::shared(['historical_po'=>'FAKE'],'VERIFIED_IAR'),'cannot spoof IAR links');
rejected(fn()=>PropertyBatchMetadata::shared(['unknown_field'=>'oops'],'HISTORICAL_OPENING'),'unknown shared field blocked');
rejected(fn()=>PropertyBatchMetadata::shared(['acquisition_type'=>'PRIVILEGED'],'HISTORICAL_OPENING'),'invalid acquisition type');
rejected(fn()=>PropertyBatchMetadata::shared(['useful_life_years'=>'100'],'HISTORICAL_OPENING'),'out of range useful life');
$u=PropertyBatchMetadata::units([['serial_number'=>'SN1','legacy_property_number'=>'OLD-1'],['serial_number'=>'SN2','location'=>'Storage']],2);
check(count($u)===2 && $u[0]['legacy_property_number']==='OLD-1','unit rows distinct');
rejected(fn()=>PropertyBatchMetadata::units([['serial_number'=>'SN1'],['serial_number'=>'sn1']],2),'duplicate serial within batch');
rejected(fn()=>PropertyBatchMetadata::units([[]],2),'missing unit row');
rejected(fn()=>PropertyBatchMetadata::units([[]],101),'batch cap');
rejected(fn()=>PropertyBatchMetadata::units([['property_tag'=>'MANUAL']],1),'manual property number invalid');
rejected(fn()=>PropertyBatchMetadata::units([['serial_number'=>str_repeat('s',121)]],1),'serial too long');
$p=PropertyBatchMetadata::profile($x,$u[0]);$back=PropertyBatchMetadata::decode($p);
check($back['shared']['historical_po']==='PO-2019-11','profile shared persisted');
check($back['unit']['legacy_property_number']==='OLD-1','profile unit persisted');
check(PropertyBatchMetadata::decode(null)['shared']===[],'old assets backward compat');
rejected(fn()=>PropertyBatchMetadata::decode('{invalid'), 'corrupt profile fail closed');
check(PropertyBatchMetadata::shared([], 'VERIFIED_IAR')['historical_dv']==='', 'IAR default no fake refs');
check(count(PropertyBatchMetadata::units(null,3))===3, 'old IAR requests still accept units by count');
echo "PASS: $n property batch metadata assertions\n";
