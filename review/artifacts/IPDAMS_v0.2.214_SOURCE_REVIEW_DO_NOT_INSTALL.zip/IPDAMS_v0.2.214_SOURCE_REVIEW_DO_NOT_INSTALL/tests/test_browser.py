from playwright.sync_api import sync_playwright
from pathlib import Path
import json
b=Path('/mnt/data/ipdams_214_work/candidate')
r=Path('/mnt/data/ipdams_214_work/baseline/assets')
app=(b/'public/assets/app.js').read_text()
assert 'ReactDOM.render(React.createElement(App, null), document.getElementById(\'root\'));' in app
app=app.replace("ReactDOM.render(React.createElement(App, null), document.getElementById('root'));", "window.__app = ReactDOM.render(React.createElement(App, null), document.getElementById('root'));")
with sync_playwright() as p:
    browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
    page=browser.new_page(viewport={'width':1320,'height':900})
    errs=[]
    page.on('pageerror',lambda e:errs.append(str(e)))
    page.set_content('<!doctype html><html><head><meta name="viewport" content="width=device-width,initial-scale=1"><style>body{font-family:Arial,sans-serif;margin:0}.field{display:block;margin:5px 0}.field input,.field select{min-width:0;box-sizing:border-box;max-width:100%}.surface{padding:12px}.section-stack{max-width:100%;padding:12px}.property-unit-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,280px),1fr));gap:12px}.property-unit-card{min-width:0}</style></head><body><div id="root"></div></body></html>')
    page.add_script_tag(content="""window.fetch = async function(url){
        const name=String(url);
        let data=[];
        if(name.includes('auth.session')) data={user:{id:1,full_name:'Test Owner',role:'SUPER_ADMIN'},organizations:[{id:7,code:'306351',kind:'SCHOOL',name:'Example School',active:1}],csrf:'test'};
        else if(name.includes('organization.hierarchy')) data={organizations:[],users:[]};
        return {ok:true,json:async()=>({data})};
    };""")
    page.add_script_tag(content=(r/'react.production.min.js').read_text())
    page.add_script_tag(content=(r/'react-dom.production.min.js').read_text())
    page.add_script_tag(content=app)
    page.wait_for_function('!!window.__app',timeout=20000)
    page.evaluate('''() => window.__app.setState({tab:'Property Accountability',propertySection:'historical',organization_id:'7',
        user:{id:1,role:'SUPER_ADMIN',full_name:'Test Owner'},
        orgs:[{id:7,code:'306351',kind:'SCHOOL',name:'Example School'}],
        lists:{items:[{id:12,name:'Printer Epson',category:'PPE',active:1}]},
        propertyRecords:{assets:[],accountability:[],received_property:[]},propertyBusy:false})''')
    page.wait_for_timeout(400)
    assert page.get_by_text('Register historical property',exact=False).count()>0,'historical panel missing'
    assert page.get_by_text('Historical PO No. (optional)').count()>0,'PO evidence field missing'
    assert page.get_by_text('Historical IAR No. (optional)').count()>0,'IAR evidence missing'
    assert page.get_by_text('Historical DV No. (optional)').count()>0,'DV evidence missing'
    count=page.locator('input[type=number]').first
    count.fill('3')
    page.wait_for_timeout(300)
    assert page.get_by_text('Physical unit 3',exact=False).count()>0,'three unique unit panels missing'
    page.get_by_role('tab',name='Edit Property Details').click()
    assert page.get_by_text('Property numbers, official IAR lineage',exact=False).count()>0,'edit guard note missing'
    page.get_by_role('tab',name='Register from IAR').click()
    assert page.get_by_text('Register accepted property',exact=False).count()>0,'IAR registration disappeared'
    assert not errs, 'JS errors '+str(errs)
    page.set_viewport_size({'width':390,'height':844});page.get_by_role('tab',name='Historical Property').click();page.wait_for_timeout(150)
    document_width=page.evaluate('document.documentElement.scrollWidth');assert document_width<=402,document_width
    print('PASS Chromium bundled React16: historical 3-unit batch, PO/IAR/DV references, edit safety, IAR form, mobile width, no JS errors')
    browser.close()
