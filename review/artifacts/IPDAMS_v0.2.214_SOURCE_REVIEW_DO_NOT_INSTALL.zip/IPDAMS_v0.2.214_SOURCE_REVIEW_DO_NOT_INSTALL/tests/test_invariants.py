from pathlib import Path
import re, zipfile, hashlib, json
base=Path('/mnt/data/ipdams_214_work')
cur=base/'candidate';pred=base/'predecessor'
zip_src=Path('/mnt/data/IPDAMS_v0.2.213_AUTO_PROPERTY_NUMBERS_FROM_v0.2.212_STAGING_REVIEW.zip')
with zipfile.ZipFile(zip_src) as z:
 m=json.loads(z.read('release.json'))
 assert (m['version'],m['from_version'])==('0.2.213','0.2.212')
 for path,sha in m['files'].items():
  assert hashlib.sha256((pred/path).read_bytes()).hexdigest()==sha, path
print('PASS exact v0.2.213 modified predecessor files',len(m['files']))
app=(cur/'app/Domain.php').read_text()
api=(cur/'public/api/index.php').read_text()
js=(cur/'public/assets/app.js').read_text()
assert 'PropertyRegistrationNumbers::reserve($this->db,$org,$count)' in app
assert 'PropertyRegistrationNumbers::reserve($this->db,$org,$unitCount)' in app
for v in ['HISTORICAL_OPENING','VERIFIED_IAR','propertyRegistrationDetail','correctPropertyRegistration','PROPERTY_DETAILS_CORRECTED','registration_batch_key','expected_versions','accountability_documents']:
 assert v in app,v
assert "'asset.opening'=>'recordAsset'" in api
assert "'property.registration.correct'=>'correctPropertyRegistration'" in api
assert "'property.registration.detail'" in api
assert "'property.registration.correct'" in api.split('SET TRANSACTION ISOLATION LEVEL READ COMMITTED')[0]
for v in ['Historical Property','Edit Property Details','Historical PO No.','Historical IAR No.','Historical DV No.','propertyUnitGrid']:
 assert v in js,v
for path in (cur/'migrations').glob('*.sql'):
 sql=path.read_text().strip()
 assert sql.startswith('ALTER TABLE assets ADD COLUMN IF NOT EXISTS ')
 assert sql.endswith('NULL;')
 assert not any(word in sql for word in ['DROP ','UPDATE ','DELETE ','TRUNCATE '])
 assert len(sql.split(';'))==2 and sql.count(';')==1
print('PASS 2 additive schema operations and API/authorization/numbering/audit route invariants')
