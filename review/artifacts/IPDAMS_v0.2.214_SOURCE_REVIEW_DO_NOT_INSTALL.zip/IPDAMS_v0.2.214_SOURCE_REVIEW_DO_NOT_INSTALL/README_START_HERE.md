# IPDAMS v0.2.214 — Historical Property Batches + Controlled Corrections

**Source review / integration candidate only. DO NOT INSTALL.** Based on the user's reported installed v0.2.213; exact original v0.2.213 release modified-file SHA-256 lineage revalidated. This ZIP has **no `release.json`** and intentionally cannot be uploaded through the IPDAMS versioned updater. This is a functioning source implementation and test suite, **not** a real MariaDB security/financial release approval.

## Functionality implemented in source

- Existing `Property Accountability` screen gets **Register from IAR**, **Historical Property**, **Edit Property Details**, plus existing Asset Register, Issue ICS/PAR and Issued Slips.
- Historical registration captures a supported PPE or SEMI_EXPENDABLE catalog item, acquisition date and optional cost, 1–100 units, plus one shared batch profile: brand, model, acquisition type, useful life, optional free-text historical PO No / IAR No / DV No, documentary note. Those strings **never create real PO/IAR/DV links**, checks, stock movement or fund postings.
- Each unit has its own serial number, physical location, condition, legacy school property number and optional historical custodian *reference* (not an official custody transfer). All units get immutable school property numbers from **the existing 0.2.213 lifetime school counter** inside the same registration transaction. A failed batch must roll back all asset rows and numbers.
- Verified IAR source registration reuses v0.2.213 locks/accepted quantity/source-lot checks and immutable PO/IAR values. New optional shared brand/model, useful life and unit fields are stored but source PO/IAR/DV IDs can never be supplied as evidence strings to manufacture a link.
- Persist the batch identity and descriptive profiles on the existing assets, not a second stock ledger. Two additive MariaDB `assets` columns are proposed:
  `registration_batch_key VARCHAR(48) NULL`, `property_profile TEXT NULL`. Source includes two single-statement allowlist-style migrations. No CREATE TABLE, no migrations executed.
- Read-only correction preview returns exact affected asset IDs and SHA-256 state versions. **Unit correction** changes serial/location/condition/legacy tag/evidence reference for one unit. **Batch correction** changes descriptive shared fields of only assets with the same randomly assigned registration_batch_key, never all items with the same PO/IAR. Both require 12+ character reason, locked school/asset rows, before/after append-only audit and optimistic stale-snapshot version check.
- Corrections cannot edit original property number, organization, item classification, acquisition value/date, IAR link, status or official custodian. Once any ICS/PAR (including historically cancelled records) exists, corrections through this generic form are blocked; use a separately approved accountability procedure.
- School/organization write scope and Division MOOE VIEWER hard restrictions remain in existing Domain server checks. No new special grant permits Division school users to register opening assets.

## Changed application files (compared with known v0.2.213 source)

- `app/Domain.php`: preserve all existing Domain services; add validated batch fields to verified-IAR registration, batch-aware historical opening, authorized edit preview, locked/audited correction.
- `app/PropertyBatchMetadata.php`: new typed validator/parser; no database usage.
- `public/api/index.php`: add scoped property registration detail and audited correction routes behind existing CSRF/idempotency dispatch.
- `public/assets/app.js`: compact React16 batch form and edit panels with unique unit rows.
- `public/assets/property-batch-registration.css`: scoped responsive form layout.
- `public/app.html`: new scoped stylesheet; cache bust only.
- `migrations/20261026_property_batch_key.sql` and `migrations/20261026_property_profile.sql`: two **proposed**, non-executed ALTER ADD COLUMN IF NOT EXISTS statements.

## Local tests completed

- Original uploaded v0.2.213 six modified application files all exactly SHA-matched their release manifest.
- `php -l` for PHP sources and `node --check` for the frontend passed.
- `php tests/test_property_metadata.php`: 18 unit assertions passed (source distinction, fake links rejection, duplicate serial, unit count, field validation, metadata persistence, backward-compatible missing fields).
- `python tests/test_invariants.py`: v0.2.213 predecessor and route/numbering/append-only audit/additive-migration structural checks passed.
- `python tests/test_browser.py`: Chromium against the existing bundled React 16 code, in an in-memory synthetic fixture: historical registration, 3 independent unit rows, all three optional references, edit and existing IAR form, 390px layout, no JS exceptions passed. Fixture is **not the live application**.

## Critical release blockers — do not attempt official data or production installation

1. A separate TEST/STAGING website and genuine MariaDB schema matching deployed v0.2.213; independent verified full website/database backups and restore rehearsal. Current tool environment has no `pdo_mysql` driver or MariaDB server, so actual DB transaction code was **not exercised**.
2. Confirm current deployed `app/Domain.php`, `public/api/index.php`, `public/assets/app.js` hashes match the verified .213 lineage; preserve other custom Hostinger edits.
3. Review updater's **current** migration parser, schema migration compatibility and interrupted-DDL recovery using isolated DB. The available older SettingsService showed an allowlist for these additive column forms; do not assume newer deployed parser is unchanged.
4. Create verified school A/B/C test accounts and test: two physical historical units, exact property number/lifetime continuity, independent school B numbering, no new stock/PO/IAR/DV/check, and accurate Division Consolidation counts.
5. Verify genuine IAR source registered quantity locks: never exceed accepted quantity, avoid duplicate IAR lot movement, never manufacture a PO/DV source link from a text reference.
6. Parallel same-school registrations (2 sessions), retries with same idempotency key, failed third unit rollback, serial collisions and concurrent edits. Verify counter and append-only audit in MariaDB.
7. Confirm **both** unit and batch edit accurately distinguish the intended asset IDs. Stale preview, different school, Division-school user, and VIEWER must deny; any finalized/cancelled ICS/PAR blocks general edits. Verify all existing print/PDF and financial records unchanged.
8. Test React16 end-to-end using real auth/session, mobile width, and SQL migration restoration. Do not rely solely on synthetic checks.

## Release decision

**No v0.2.214 installable release has been issued.** Do not rename this ZIP or manually copy these changes to live IPDAMS. The intended next release is v0.2.214 **from installed v0.2.213**, only after the above staged MariaDB and policy reviews pass. The staged UI prototype from the previous response remains separately available.
