<?php
declare(strict_types=1);
const IPDAMS_ROOT = __DIR__ . '/..';
date_default_timezone_set('Asia/Manila');
function loadEnv(string $path): void {
    if (!is_file($path)) return;
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$key,$val] = explode('=', $line, 2);
        $key = trim($key); $val = trim($val, " \t\n\r\0\x0B\"'");
        if (getenv($key) === false) putenv($key.'='.$val);
    }
}
loadEnv(IPDAMS_ROOT.'/.env');
function cfg(string $key, string $default = ''): string { $v=getenv($key); return $v===false?$default:$v; }
function database(): PDO {
    static $db = null;
    if (!$db) {
        $db = new PDO('mysql:host='.cfg('DB_HOST','localhost').';port='.cfg('DB_PORT','3306').';dbname='.cfg('DB_NAME','ipdams').';charset=utf8mb4',cfg('DB_USER'),cfg('DB_PASSWORD'),[
            PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES=>false,
        ]);
        $db->exec("SET time_zone = '+08:00'");
    }
    return $db;
}
final class DomainError extends RuntimeException {
    public function __construct(string $message, public readonly int $status=422) { parent::__construct($message); }
}
function demand(bool $condition, string $message, int $status=422): void { if (!$condition) throw new DomainError($message,$status); }
function moneyCents(mixed $value): int {
    $value=(string)$value;
    demand((bool)preg_match('/^\d{1,16}(\.\d{1,2})?$/',$value),'Invalid monetary amount');
    [$whole,$fraction]=array_pad(explode('.',$value,2),2,'');
    demand(strlen($whole)<=14,'Monetary amount exceeds supported bounds');
    return (int)$whole*100+(int)str_pad($fraction,2,'0');
}
function moneyString(int $cents): string { $sign=$cents<0?'-':''; $abs=abs($cents); return $sign.sprintf('%d.%02d',intdiv($abs,100),$abs%100); }
function qtyMillis(mixed $value): int {
    $value=(string)$value;
    demand((bool)preg_match('/^\d{1,11}(\.\d{1,3})?$/',$value),'Invalid quantity');
    [$whole,$fraction]=array_pad(explode('.',$value,2),2,'');
    return (int)$whole*1000+(int)str_pad($fraction,3,'0');
}
function qtyString(int $n): string { return sprintf('%d.%03d',intdiv($n,1000),$n%1000); }
function totalCents(int $unitCents, int $qtyMilli): int { return intdiv($unitCents*$qtyMilli+500,1000); }
function taxCents(int $baseCents,string $decimalRate): int {
    demand((bool)preg_match('/^0(\.\d{1,6})?$|^1(\.0{1,6})?$/',$decimalRate),'Invalid tax rate');
    [$w,$f]=array_pad(explode('.',$decimalRate,2),2,'');
    $million=(int)$w*1000000+(int)str_pad($f,6,'0');
    return intdiv($baseCents*$million+500000,1000000);
}
function q(PDO $db,string $sql,array $params=[]): PDOStatement { $stmt=$db->prepare($sql); $stmt->execute($params); return $stmt; }
function one(PDO $db,string $sql,array $params=[]): ?array { $row=q($db,$sql,$params)->fetch(); return $row===false?null:$row; }
function requiredString(array $data,string $key,int $max=240): string {
    $s=trim((string)($data[$key]??''));
    demand($s!=='' && mbSafeLen($s)<=$max,"Invalid or missing $key"); return $s;
}
function mbSafeLen(string $s): int { return function_exists('mb_strlen')?mb_strlen($s):strlen($s); }
function idOf(array $data,string $key): int {
    $v=$data[$key]??null; demand(is_int($v)||is_string($v)&&ctype_digit($v),"Invalid $key");
    demand((int)$v>0,"Invalid $key"); return (int)$v;
}
function rowsRequired(array $d,string $key): array { demand(isset($d[$key])&&is_array($d[$key])&&count($d[$key])>0&&count($d[$key])<=100,"Required nonempty $key (max 100)"); return $d[$key]; }
function currentUser(PDO $db): array {
    demand(isset($_SESSION['uid']),'Sign in to continue',401);
    $u=one($db,'SELECT id,email,full_name,role,active FROM users WHERE id=?',[(int)$_SESSION['uid']]);
    demand($u!==null&&(int)$u['active']===1,'Session expired',401);
    return $u;
}
function scope(PDO $db,array $user,int $org): void {
    if($user['role']==='SUPER_ADMIN') return;
    $ok=one($db,'SELECT 1 FROM user_organization_scopes WHERE user_id=? AND organization_id=?',[(int)$user['id'],$org]);
    demand($ok!==null,'Access denied for organization',403);
}
function allowedToWrite(array $user): void { demand($user['role']!=='VIEWER','Read-only account',403); }
function csrfCheck(): void {
    $provided=$_SERVER['HTTP_X_CSRF_TOKEN']??'';
    demand(is_string($provided)&&hash_equals((string)($_SESSION['csrf']??''),$provided),'CSRF token invalid',403);
}
function jsonOut(mixed $data,int $status=200): never { http_response_code($status); header('Content-Type: application/json; charset=utf-8'); echo json_encode(['data'=>$data],JSON_UNESCAPED_SLASHES|JSON_INVALID_UTF8_SUBSTITUTE); exit; }
