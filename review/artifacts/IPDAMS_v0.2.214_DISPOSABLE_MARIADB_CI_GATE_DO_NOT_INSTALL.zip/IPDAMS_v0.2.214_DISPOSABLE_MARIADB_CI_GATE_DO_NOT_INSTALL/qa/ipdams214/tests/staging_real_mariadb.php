<?php
/**
 * ACTUAL MARiADB STAGING GATE — property registration and edit methods.
 * Refuses production databases, refuses nonempty schemas, requires explicit operator
 * opt-in, and creates only synthetic test tables. No external HTTP or real records.
 * Usage: see README.md. Requires PHP CLI PDO MySQL + pcntl, MariaDB 10.6+.
 */
declare(strict_types=1);
require_once __DIR__.'/../app/Domain.php';
function assert214(bool $good, string $name): void {
    if (!$good) throw new RuntimeException('FAIL: '.$name);
    echo 'PASS: '.$name."\n";
}
function db214(): PDO {
    $db = new PDO(getenv('IPDAMS214_DSN'), getenv('IPDAMS214_DB_USER'), getenv('IPDAMS214_DB_PASSWORD'), [
        PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES=>false,
    ]);
    $db->exec("SET SESSION time_zone='+08:00'");
    $db->exec('SET SESSION innodb_lock_wait_timeout=15');
    return $db;
}
function safe214(PDO $db): string {
    $name=(string)$db->query('SELECT DATABASE()')->fetchColumn();
    if(!preg_match('/^ipdams214_uat_[a-z0-9]{3,30}$/D',$name))
        throw new RuntimeException('REFUSED: DB name must match ipdams214_uat_<unique_suffix>.');
    if(getenv('IPDAMS214_ALLOW_SYNTHETIC_SCHEMA')!=='YES_CREATE_NEW_EMPTY_DB')
        throw new RuntimeException('REFUSED: explicit isolated synthetic schema approval missing.');
    if(getenv('IPDAMS214_EXPECT_DB')!==$name)
        throw new RuntimeException('REFUSED: target DB and expected DB do not match.');
    return $name;
}
function noexisting214(PDO $db):void {
    $count=(int)$db->query('SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA=DATABASE()')->fetchColumn();
    if($count!==0) throw new RuntimeException('REFUSED: test schema is not completely empty; create another NEW disposable database.');
}
function createFixtures214(PDO $db):void {
    $statements=[
        "CREATE TABLE organizations (id BIGINT UNSIGNED PRIMARY KEY,code VARCHAR(24) NOT NULL UNIQUE,name VARCHAR(200) NOT NULL,kind ENUM('DIVISION','SCHOOL') NOT NULL,active TINYINT NOT NULL DEFAULT 1,parent_division_id BIGINT UNSIGNED NULL) ENGINE=InnoDB",
        "CREATE TABLE users (id BIGINT UNSIGNED PRIMARY KEY, role ENUM('SUPER_ADMIN','SCHOOL','DIVISION','VIEWER') NOT NULL,active TINYINT NOT NULL DEFAULT 1) ENGINE=InnoDB",
        "CREATE TABLE user_organization_scopes (user_id BIGINT UNSIGNED NOT NULL,organization_id BIGINT UNSIGNED NOT NULL,PRIMARY KEY(user_id,organization_id)) ENGINE=InnoDB",
        "CREATE TABLE item_catalog (id BIGINT UNSIGNED PRIMARY KEY,owner_organization_id BIGINT UNSIGNED NULL,active TINYINT NOT NULL DEFAULT 1,name VARCHAR(255) NOT NULL,category ENUM('SUPPLY','PPE','SEMI_EXPENDABLE') NOT NULL) ENGINE=InnoDB",
        "CREATE TABLE document_counters (organization_id BIGINT UNSIGNED NOT NULL,doc_type VARCHAR(16) NOT NULL,period CHAR(7) NOT NULL,next_sequence INT UNSIGNED NOT NULL,PRIMARY KEY(organization_id,doc_type,period)) ENGINE=InnoDB",
        "CREATE TABLE assets (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,organization_id BIGINT UNSIGNED NOT NULL,item_id BIGINT UNSIGNED NOT NULL,iar_line_id BIGINT UNSIGNED NULL,property_tag VARCHAR(80) NOT NULL,serial_number VARCHAR(120) NULL,acquisition_cost DECIMAL(18,2) NULL,acquired_on DATE NULL,opening_record TINYINT NOT NULL DEFAULT 0,custodian VARCHAR(180) NULL,location VARCHAR(180) NULL,condition_note VARCHAR(255) NULL,status ENUM('ACTIVE','TRANSFERRED','DISPOSED') NOT NULL DEFAULT 'ACTIVE',UNIQUE KEY uq_tag(organization_id,property_tag)) ENGINE=InnoDB",
        "CREATE TABLE accountability_documents (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,organization_id BIGINT UNSIGNED NOT NULL,asset_id BIGINT UNSIGNED NOT NULL,doc_type ENUM('ICS','PAR') NOT NULL,custodian VARCHAR(160) NOT NULL,status ENUM('FINALIZED','CANCELLED') NOT NULL DEFAULT 'FINALIZED',display_number CHAR(12) NOT NULL) ENGINE=InnoDB",
        "CREATE TABLE audit_events (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,organization_id BIGINT UNSIGNED NULL,actor_id BIGINT UNSIGNED NOT NULL,event_type VARCHAR(80) NOT NULL,entity_type VARCHAR(24) NOT NULL,entity_id BIGINT UNSIGNED NOT NULL,details JSON NOT NULL,created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP) ENGINE=InnoDB"
    ];
    foreach($statements as $sql)$db->exec($sql);
    foreach(['20261026_property_batch_key.sql','20261026_property_profile.sql'] as $name){
        $sql=trim((string)file_get_contents(__DIR__.'/../migrations/'.$name));
        if(!preg_match('/^ALTER TABLE assets ADD COLUMN IF NOT EXISTS (registration_batch_key VARCHAR\(48\)|property_profile TEXT) NULL;$/',$sql))
            throw new RuntimeException('Unapproved migration SQL file');
        $db->exec($sql);
    }
    $db->exec("INSERT INTO organizations (id,code,name,kind,active,parent_division_id) VALUES (1,'999999','Synthetic Division','DIVISION',1,NULL),(3,'306351','Synthetic School A','SCHOOL',1,1),(4,'400001','Synthetic School B','SCHOOL',1,1),(5,'500001','Synthetic Unassigned School C','SCHOOL',1,1)");
    $db->exec("INSERT INTO users (id,role,active) VALUES (1,'SUPER_ADMIN',1),(2,'DIVISION',1),(3,'VIEWER',1),(4,'SCHOOL',1)");
    $db->exec("INSERT INTO user_organization_scopes (user_id,organization_id) VALUES (2,3),(4,3)");
    $db->exec("INSERT INTO item_catalog (id,owner_organization_id,active,name,category) VALUES (10,NULL,1,'Synthetic PPE Laptop','PPE')");
    $db->exec("INSERT INTO assets (organization_id,item_id,property_tag,opening_record,status) VALUES (3,10,'306351-2506-00007',1,'ACTIVE')");
    foreach(['registration_batch_key','property_profile'] as $column){
        $stm=$db->prepare("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='assets' AND COLUMN_NAME=?");
        $stm->execute([$column]);assert214((int)$stm->fetchColumn()===1,'applied additive migration assets.'.$column);
    }
}
function unit214(string $serial):array {return ['serial_number'=>$serial,'location'=>'Synthetic Lab'];}
function payload214(int $school,array $serials):array {
    return ['organization_id'=>$school,'item_id'=>10,'unit_count'=>count($serials),
        'acquired_on'=>'2025-06-17','acquisition_cost'=>'15045.00',
        'shared'=>['brand'=>'Synthetic Epson','model'=>'S1','historical_po'=>'TEST-PO-NOT-LINKED',
            'historical_iar'=>'TEST-IAR-NOT-LINKED','historical_dv'=>'TEST-DV-NOT-LINKED'],
        'units'=>array_map('unit214',$serials)];
}
function deny214(callable $call,int $expected,string $label):void{
    try{$call();}catch(DomainError $e){assert214($e->status===$expected,$label);return;}
    throw new RuntimeException('FAIL: expected denial: '.$label);
}
$dsn=(string)getenv('IPDAMS214_DSN');
if(!preg_match('/^mysql:/',$dsn))throw new RuntimeException('REFUSED: mysql PDO DSN required');
$db=db214();$schema=safe214($db);noexisting214($db);
echo "Isolated synthetic MariaDB test: ".$schema."\n";
createFixtures214($db);
$actor=new Domain($db,['id'=>1,'role'=>'SUPER_ADMIN']);
$r=$actor->recordAsset(payload214(3,['SYNTH-1','SYNTH-2']));
assert214(count($r['asset_ids'])===2,'real MariaDB 2-unit batch commit');
assert214(str_ends_with($r['property_numbers'][0],'-00008')&&str_ends_with($r['property_numbers'][1],'-00009'),'seed existing property sequence and preserve lifetime');
assert214((int)$db->query("SELECT COUNT(*) FROM audit_events WHERE event_type='HISTORICAL_PROPERTY_REGISTERED'")->fetchColumn()===2,'real MariaDB two append-only asset audit events');
$schoolB=$actor->recordAsset(payload214(4,['B-ONLY']));
assert214(str_ends_with($schoolB['property_numbers'][0],'-00001'),'real MariaDB school B numbering independent');
$before=(int)$db->query("SELECT COUNT(*) FROM assets WHERE organization_id=3")->fetchColumn();
$db->beginTransaction();
$tmp=PropertyRegistrationNumbers::reserve($db,3,2);
$db->exec("INSERT INTO assets (organization_id,item_id,property_tag,opening_record) VALUES (3,10,".$db->quote($tmp[0]).",1)");
$db->rollBack();
assert214((int)$db->query("SELECT COUNT(*) FROM assets WHERE organization_id=3")->fetchColumn()===$before,'real MariaDB rollback of uncommitted asset insertion');
// Force an actual InnoDB failure after the first unit of a two-unit batch.
// The trigger is created ONLY in the independently checked empty disposable schema.
// This test must prove that rows, audit entries, AND lifetime number reservations
// all roll back when the second physical unit cannot be inserted.
$db->exec("CREATE TRIGGER ipdams214_synthetic_fail_batch BEFORE INSERT ON assets FOR EACH ROW
    BEGIN IF NEW.serial_number = 'FAIL-BATCH' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Synthetic rejected second unit';
    END IF; END");
$beforeFailureCount=(int)$db->query('SELECT COUNT(*) FROM assets WHERE organization_id=3')->fetchColumn();
$beforeFailureAudit=(int)$db->query("SELECT COUNT(*) FROM audit_events WHERE event_type='HISTORICAL_PROPERTY_REGISTERED'")->fetchColumn();
$beforeFailureNext=(int)$db->query("SELECT next_sequence FROM document_counters WHERE organization_id=3 AND doc_type='PROPERTY_TAG' AND period='ALLTIME'")->fetchColumn();
$failureObserved=false;
try {
    $actor->recordAsset(payload214(3,['TEMP-SHOULD-ROLL-BACK','FAIL-BATCH']));
} catch (PDOException $e) {
    $failureObserved=true;
}
assert214($failureObserved,'real MariaDB synthetic second-unit insert rejected');
assert214((int)$db->query('SELECT COUNT(*) FROM assets WHERE organization_id=3')->fetchColumn()===$beforeFailureCount,
    'real MariaDB middle-batch failure rolled back all asset rows');
assert214((int)$db->query("SELECT COUNT(*) FROM audit_events WHERE event_type='HISTORICAL_PROPERTY_REGISTERED'")->fetchColumn()===$beforeFailureAudit,
    'real MariaDB middle-batch failure rolled back audit rows');
assert214((int)$db->query("SELECT next_sequence FROM document_counters WHERE organization_id=3 AND doc_type='PROPERTY_TAG' AND period='ALLTIME'")->fetchColumn()===$beforeFailureNext,
    'real MariaDB middle-batch failure rolled back lifetime property counter');
$r3=$actor->recordAsset(payload214(3,['SYNTH-3']));
assert214(str_ends_with($r3['property_numbers'][0],'-00010'),'real MariaDB rollback did not consume counter');
$detail=$actor->propertyRegistrationDetail(['organization_id'=>3,'asset_id'=>$r['asset_ids'][0]]);
assert214(count($detail['batch_units'])===2&&count($detail['versions'])===2,'real MariaDB exact batch edit preview');
$unit=array_merge($detail['unit'],['serial_number'=>'SYNTH-CORRECTED','location'=>'Synthetic Room B']);
$correction=['organization_id'=>3,'asset_id'=>$r['asset_ids'][0],'mode'=>'UNIT','reason'=>'Synthetic correction approval TEST ONLY',
 'expected_asset_ids'=>[$r['asset_ids'][0]],
 'expected_versions'=>array_values(array_filter($detail['versions'],fn($v)=>(int)$v['id']===(int)$r['asset_ids'][0])),
 'unit'=>$unit];
$changed=$actor->correctPropertyRegistration($correction);
assert214(count($changed['corrected_asset_ids'])===1,'real MariaDB individual correction committed');
deny214(fn()=> $actor->correctPropertyRegistration($correction),409,'real MariaDB stale edit denied');
$detail=$actor->propertyRegistrationDetail(['organization_id'=>3,'asset_id'=>$r['asset_ids'][0]]);
$shared=$detail['shared'];$shared['model']='S2';
$batchCorrection=['organization_id'=>3,'asset_id'=>$r['asset_ids'][0],'mode'=>'BATCH','reason'=>'Synthetic shared batch correction',
    'expected_asset_ids'=>array_map(fn($v)=>(int)$v['id'],$detail['versions']),
    'expected_versions'=>$detail['versions'],'shared'=>$shared];
$edited=$actor->correctPropertyRegistration($batchCorrection);
assert214(count($edited['corrected_asset_ids'])===2,'real MariaDB shared batch correction commits exactly two assets');
$db->exec("INSERT INTO accountability_documents (organization_id,asset_id,doc_type,custodian,status,display_number) VALUES (3,".(int)$r['asset_ids'][0].",'ICS','Synthetic Employee','CANCELLED','TEST-ICS-01')");
$detail=$actor->propertyRegistrationDetail(['organization_id'=>3,'asset_id'=>$r['asset_ids'][0]]);
$batchCorrection['expected_versions']=$detail['versions'];
deny214(fn()=> $actor->correctPropertyRegistration($batchCorrection),409,'real MariaDB cancelled ICS blocks general batch correction');
$division=new Domain($db,['id'=>2,'role'=>'DIVISION']);
deny214(fn()=> $division->recordAsset(payload214(3,['DIVISION-DENY'])),403,'assigned Division user cannot register opening property');
$viewer=new Domain($db,['id'=>3,'role'=>'VIEWER']);
deny214(fn()=> $viewer->recordAsset(payload214(3,['VIEWER-DENY'])),403,'MOOE viewer cannot register opening property');
$cross=new Domain($db,['id'=>4,'role'=>'SCHOOL']);
deny214(fn()=> $cross->propertyRegistrationDetail(['organization_id'=>4,'asset_id'=>$r['asset_ids'][0]]),403,'unauthorized school selection denied');
// Close inherited parent sockets BEFORE fork; children must own fresh connections.
unset($actor,$division,$viewer,$cross,$db);
// Two genuinely separate MySQL connections execute actual PHP batch methods concurrently.
if(!function_exists('pcntl_fork'))throw new RuntimeException('pcntl extension required for concurrent test');
$children=[];
for($i=0;$i<4;$i++){
    $pid=pcntl_fork();if($pid===-1)throw new RuntimeException('Cannot fork');
    if($pid===0){
       try{
         $childDb=db214();$childActor=new Domain($childDb,['id'=>1,'role'=>'SUPER_ADMIN']);
         usleep(5000*(4-$i));
         $created=$childActor->recordAsset(payload214(3,['PARALLEL-'.$i]));
         if(count($created['asset_ids'])!==1)exit(2);
         exit(0);
       }catch(Throwable $e){fwrite(STDERR,'Child registration failed: '.$e->getMessage()."\n");exit(3);}
    }else{$children[]=$pid;}
}
foreach($children as $pid){pcntl_waitpid($pid,$status);assert214(pcntl_wifexited($status)&&pcntl_wexitstatus($status)===0,'concurrent child registration completed');}
$db=db214();
$ids=$db->query("SELECT property_tag FROM assets WHERE organization_id=3 AND serial_number LIKE 'PARALLEL-%' ORDER BY property_tag")->fetchAll(PDO::FETCH_COLUMN);
assert214(count($ids)===4&&count(array_unique($ids))===4,'real MariaDB 4 parallel property numbers unique');
assert214(preg_match('/-00011$/',$ids[0])===1&&preg_match('/-00014$/',$ids[3])===1,'real MariaDB concurrent sequences contiguous 11–14');
assert214((int)$db->query("SELECT COUNT(*) FROM audit_events WHERE event_type='HISTORICAL_PROPERTY_REGISTERED'")->fetchColumn()===8,'real MariaDB one audit record per synthetic registered asset');
echo "PASS: isolated real MariaDB domain-method smoke test. Still NOT full hosted app/API/updater release approval.\n";
