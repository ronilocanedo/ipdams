# IPDAMS v0.2.214 — REAL MariaDB isolated staging execution kit

**NON-INSTALLABLE / DO NOT UPLOAD TO SYSTEM UPDATES.** This is a reproducible test harness, *not* a report that tests have been run. Its target is a **fresh empty MariaDB schema** named `ipdams214_uat_<unique_suffix>`. The harness has no DROP/DELETE/TRUNCATE, but it creates synthetic tables and records; **never point it at production or a shared database**. Keep all credentials in environment variables, not in commands pasted into chats.

## Requirements
- MariaDB 10.6+ on a separate staging server (or isolated local environment), PHP 8.2+ CLI with `pdo_mysql` and `pcntl` and `mbstring` (mbstring has fallback). This current ChatGPT container **does not have MariaDB or `pdo_mysql`** and cannot run these tests.
- Exact source PHP in `app/` is taken from the noninstallable v0.2.214 candidate. No credentials or official school/accounting/financial data.
- An operator creates a completely EMPTY disposable database matching `ipdams214_uat_<unique_suffix>` and grants one test-only account permission to create/alter/insert within that one database. No global SQL privileges.

## Launch (run from the extracted kit folder, not the live website)

```bash
export IPDAMS214_DSN='mysql:host=127.0.0.1;port=3306;dbname=ipdams214_uat_abc123;charset=utf8mb4'
export IPDAMS214_DB_USER='dedicated_test_user'
# Enter password locally without saving to command history or uploading secrets.
read -r -s -p 'Synthetic MariaDB test password: ' IPDAMS214_DB_PASSWORD; echo
export IPDAMS214_DB_PASSWORD
export IPDAMS214_EXPECT_DB='ipdams214_uat_abc123'
export IPDAMS214_ALLOW_SYNTHETIC_SCHEMA='YES_CREATE_NEW_EMPTY_DB'
php -l tests/staging_real_mariadb.php
php tests/staging_real_mariadb.php
```

The PHP script refuses a non-MySQL DSN, nonconforming database name, mismatch with `IPDAMS214_EXPECT_DB`, missing explicit opt-in and any nonempty database. It does not create/drop a database; after a run, leave the synthetic DB available for inspection. For a repeat run create a **new** distinct empty disposable schema.

## Direct tests on real MariaDB
1. Actual `Domain::recordAsset()` with 2 physical units and imported original-number seed 00007; generated sequences 00008, 00009.
2. Genuine MariaDB ADD COLUMN migration compatibility (both proposed fields), audit persistence, independent school B number 00001.
3. Genuine transaction rollback of uncommitted asset+number reservation, followed by next valid number 00010.
4. Actual `Domain::propertyRegistrationDetail()`; exact two-unit batch, per-unit correction, stale version 409, exact two-unit shared-batch correction.
5. Cancelled ICS lock; assigned Division User and MOOE viewer registration denials; cross-school access denial.
6. Four separate PHP child processes with four **separate PDO connections** creating same-school property concurrently. Test unique and consecutive numbers 00011–00014; verify audit count.

## Limitations / further mandatory gates
- This test uses reduced **synthetic** SQL fixtures (not the full active v0.2.213 site schema), with original asset/document-counter field types and new migration columns. It does NOT prove updater migration interruption/recovery, live PHP HTTP login, CSRF, idempotent retries, finalized IAR registration, full signatory and ICS/PAR behavior, restoring a full-site backup, or real high-volume performance.
- The source files in this kit deliberately do NOT include an installable `release.json` or target any hosted instance. Manual copying onto production is prohibited.
- Do not share database passwords or backups with the assistant. Report only sanitized PASS/FAIL output and MariaDB version; remove identifying data.

**Release status:** v0.2.213 is owner-confirmed installed. v0.2.214 is still unapproved source review until this and the full 12-gate authenticated hosted staging acceptance pass.
