# IPDAMS v0.2.214 — opt-in disposable MariaDB CI gate

**DO NOT INSTALL in IPDAMS. DO NOT upload this ZIP to System Updates.**

This is a proposed manual GitHub Actions runner for a **private, authorized development repository**, not an action we executed. It is not tied to the public website or production DB, and has no deployment step. The credentials in the workflow are fixed **synthetic CI-only** values created in the ephemeral MariaDB service; never reuse them for any real system or copy any real credentials into this project.

## Operator path

1. In a temporary private repository/branch controlled by the project owner, extract this ZIP **outside** the repository first, then copy the wrapper folder's `.github/` and `qa/` directories into the root of a temporary private test branch. Review paths before copying and do not overwrite the active IPDAMS application source. The candidate PHP files stay in `qa/ipdams214/`, not in the live `app/` folder.
2. Inspect all code and workflow against your own organization's security and network policies; approve the third-party setup-PHP action as appropriate. Commit only test code to the private test branch. Do not grant deployment tokens, database secrets, or production network access.
3. In GitHub **Actions > IPDAMS 0.2.214 isolated MariaDB test gate > Run workflow**, launch it on that branch. Actions availability and runner network are outside this ChatGPT session.
4. Review failure logs. Report only sanitized PASS/FAIL lines and MariaDB/PHP versions. The workflow provisions a *fresh* `ipdams214_uat_ci987` MariaDB 10.11 container on an isolated runner. It does not connect to any IPDAMS website.

## Expanded real-InnoDB assertions

In addition to the earlier kit, the harness now creates one **synthetic trigger in the empty test DB only** that deliberately fails the second unit of a two-unit registration. It checks that the first unit, appended audit rows and reserved lifetime sequence all roll back, before testing the next successful number. The remaining school separation, serial edits, batch edits, ICS/PAR lock and 4-session concurrent registration scenarios remain. This does not alter the candidate application's production source; only the isolated test script was amended.

## Release gate remains OPEN until separately verified

- This reduced synthetic schema is not the full installed v0.2.213 MariaDB schema.
- The current deployed SettingsService migration parser and interrupted database DDL recovery have not been confirmed by this workflow.
- Authenticated HTTP/CSRF/idempotent retry tests, real finalized IAR linkage and actual backup restore must be performed on isolated, appropriately secured full staging.
- School role/scope, issued ICS/PAR, and historical record financial-impact review must be signed off.
- **There is no installable v0.2.214 update. Installed version remains owner-confirmed v0.2.213.**
